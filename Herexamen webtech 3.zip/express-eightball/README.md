# Repo for Zell's CRUD, Express and MongoDB tutorial

- [Demo](https://crud-express-mongo.herokuapp.com)
- [Tutorial](http://zell-weekeat.com/crud-express-mongodb)

## Installation

1. Clone repo
2. run `npm install` 

## Usage 

1. run `npm run dev`
2. Navigate to `localhost:3000`
3. Have fun ;)
